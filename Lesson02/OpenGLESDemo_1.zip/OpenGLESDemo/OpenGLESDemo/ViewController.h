//
//  ViewController.h
//  OpenGLESDemo
//
//  Created by Colin on 17/1/13.
//  Copyright © 2017年 Colin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

